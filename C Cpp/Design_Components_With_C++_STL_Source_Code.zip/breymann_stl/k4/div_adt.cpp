// k4/div_adt.cpp
#include<stack> 
#include<queue>
#include<deque>
#include<list>
#include<vector>
#include<iostream>

int main() {
    std::queue<int, std::list<int> > aQueue; // list container

    int numbers[] = {1, 5, 6, 0, 9, 1, 8, 7, 2};
    const int count = sizeof(numbers)/sizeof(int);

    std::cout << "Put numbers into the queue:" << std::endl;

    for(int i = 0; i < count; ++i) {
         std::cout.width(6); std::cout << numbers[i];
         aQueue.push(numbers[i]);
    }

    std::stack<int> aStack;             //  default container

    std::cout << "\n\n Read numbers from the queue (same "
            "order)\n and put them into the stack:"
         << std::endl;

    while(!aQueue.empty()) {
         int Z = aQueue.front();  // read value
         std::cout.width(6); std::cout << Z;
         aQueue.pop();            // delete value
         aStack.push(Z);
    }
    // ... (to be continued)

    std::priority_queue<int, std::vector<int>, std::greater<int> > aPrioQ;
    // {\tt greater}: small elements first (= high priority)
    // {\tt less}: large elements first

    std::cout << "\n\n Read numbers from the stack "
            "(reverse order!)\n"
            " and put them into the priority queue:"  << std::endl;

    while(!aStack.empty()) {
         int Z = aStack.top();      // read value
         std::cout.width(6); 
         std::cout << Z;            // display
         aStack.pop();              // delete value
         aPrioQ.push(Z);
    }

    std::cout << "\n\n Read numbers from the priority queue "
            "(sorted order!)" << std::endl;

    while(!aPrioQ.empty()) {
         int Z = aPrioQ.top();       // read value
         std::cout.width(6); 
         std::cout << Z;             // display
         aPrioQ.pop();               // delete value
    }
    std::cout << std::endl;
}
