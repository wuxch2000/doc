// map1.cpp     Example for map
#include<map>
#include<string>
#include<iostream>

// two typedefs for abbreviations
typedef std::map<long, std::string>   MapType; // comparison object: less<long>()
typedef MapType::value_type ValuePair;

int main() {
    MapType aMap;

    aMap.insert(ValuePair(836361136, "Andrew"));
    aMap.insert(ValuePair(274635328, "Berni"));
    aMap.insert(ValuePair(260736622, "John"));
    aMap.insert(ValuePair(720002287, "Karen"));
    aMap.insert(ValuePair(138373498, "Thomas"));
    aMap.insert(ValuePair(135353630, "William"));
    // insertion of Xaviera is not executed, because
    // the key already exists.
    aMap.insert(ValuePair(720002287, "Xaviera"));

    /* Due to the underlying implementation, the output of the names
       is sorted by numbers: */

    std::cout << "Output:\n";
    MapType::const_iterator iter = aMap.begin();
    while(iter != aMap.end()) {
       std::cout << (*iter).first << ':'     // number
                 << (*iter).second           // name
                 << std::endl;
          ++iter;
    }

    std::cout << "Output of the name after entering the number\n"
         << "Number: ";
    long Number;
    std::cin >> Number;
    iter = aMap.find(Number);         // O(log N), see text

    if(iter != aMap.end())
       std::cout << (*iter).second << ' ' // O(1)
                 << aMap[Number]          // O(log N)
                 << std::endl;
    else std::cout << "Not found!" << std::endl;
}
