// k2/identify/main.cpp
#include<iterator>
#include<fstream>
#include"identif.h"

int main( ) {
    // defining and opening of input and output files
    std::ifstream Source("main.cpp");
    std::ofstream Target("idlist");

    std::istream_iterator<Identifier> iPos(Source), End;

    // please note the separator string `\n':
    std::ostream_iterator<Identifier> oPos(Target, "\n");

    if(iPos == End)
       std::cout << "File not found!" << std::endl;
    else  {
       while(iPos != End) *oPos++ = *iPos++;
       std::cout << "file idlist generated!\n";
    }
}
