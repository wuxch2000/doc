// k5/find_end.cpp:  find a subsequence within a sequence

#include<algorithm>
#include<vector>
#include<iostream>

using namespace std;

int main() {
    vector<int> v(8);
    vector<int> subsequence1(3);
    vector<int> subsequence2(2);

    /* initialize vector and subsquences */
    for(size_t i = 0; i < v.size(); ++i)
        v[i] = 2*i;                     // all even

    subsequence1[0] = 4;
    subsequence1[1] = 6;
    subsequence1[2] = 8;

    subsequence2[0] = 2;
    subsequence2[1] = 1;

    cout << "vector  ";
    for(size_t i = 0; i < v.size(); ++i)
       cout << v[i] << " ";
    cout << endl;

    // search for subsequence 1
    cout << "subsequence1  (";
    for(size_t i = 0; i < subsequence1.size(); ++i)
       cout << subsequence1[i] << " ";
    cout << ")" << endl;
    vector<int>::const_iterator iter
        = find_end(v.begin(), v.end(), subsequence1.begin(), subsequence1.end());

    if(iter != v.end()) {
        cout << "is part of the vector. The first occurence starts at position "
             << (iter - v.begin())
             << "." << endl;
    }
    else cout << "is not part of the vector." << endl;

    // search for subsequence 2
    cout << "subsequence2  (";
    for(size_t i = 0; i < subsequence2.size(); ++i)
       cout << subsequence2[i] << " ";
    cout << ")" << endl;

    iter = find_end(v.begin(), v.end(), subsequence2.begin(), subsequence2.end());

    if(iter != v.end()) {
        cout << "is part of the vector. It starts at position "
             << (iter - v.begin())
             << "." << endl;
    }
    else cout << "is not part of the vector." << endl;

}
