// k5/rshuffle.cpp
// Example for random_shuffle()
#include<algorithm>
#include<vector>
#include<showseq.h>
#include<iota.h>
#include<rand.h>
using namespace std;

int main() {
    vector<int> v(12);
    br_stl::iota(v.begin(), v.end(), 0);   // 0 1 2 3 4 5 6 7 8 9 10 11
    
    br_stl::RAND aRAND;
    random_shuffle(v.begin(), v.end(), aRAND);
    br_stl::showSequence(v);               // 1 5 9 8 3 11 2 0 10 6 7 4 

    // use of the system-internal random number generator
    random_shuffle(v.begin(), v.end());
    br_stl::showSequence(v);               // 5 4 6 8 7 2 1 3 10 9 11 0 
}
