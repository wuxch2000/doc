// k5/mergesort_list.cpp  // with list instead of vector
#include<algorithm>
#include<showseq.h>
#include<list>
#include<myrandom.h>

template<class ForwardIterator, class OutputIterator>
void mergesort(ForwardIterator first,
               ForwardIterator last,
               OutputIterator result) {
    typename std::iterator_traits<ForwardIterator>::difference_type 
                        n    = std::distance(first, last),
                        Half = n/2;
    ForwardIterator Middle = first;
    std::advance(Middle, Half);

    if(Half > 1)            // sort left half, if needed
        mergesort(first, Middle, result);  // recursion

    if(n - Half > 1) {      // sort right half if needed
        OutputIterator result2 = result;
        std::advance(result2, Half);
        mergesort(Middle, last, result2);  // recursion
    }

    // merge both halves and copy back the result
    OutputIterator End =
          std::merge(first, Middle, Middle, last, result);
    std::copy(result, End, first);
}


int main() {     // with list instead of vector
    std::list<int> v;
    for(size_t i = 0; i < 20; ++i)
        v.push_front(0);            // create space
    br_stl::Random whatAChance(1000);
    std::generate(v.begin(), v.end(), whatAChance);
    br_stl::showSequence(v);     // random numbers

    std::list<int> buffer = v;
    mergesort(v.begin(), v.end(), buffer.begin());
    br_stl::showSequence(v);     // sorted sequence
}
