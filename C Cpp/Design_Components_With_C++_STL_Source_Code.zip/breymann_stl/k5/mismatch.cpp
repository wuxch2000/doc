// k5/mismatch.cpp
#include<algorithm>
#include<vector>
#include<set>
#include<showseq.h>

int main() {
    std::vector<int> v(8);

    for(register size_t i = 0; i < v.size(); ++i)
        v[i] = 2*i;                 // sorted sequence

    std::set<int> s(v.begin(), v.end()); // initialize set} with v
    v[3] = 7;                       // insert mismatch

    br_stl::showSequence(v);                // display
    br_stl::showSequence(s);

    // comparison for match with iterator pair 'where'
    std::pair<std::vector<int>::iterator, 
                 std::set<int>::iterator>    
          where = std::mismatch(v.begin(), v.end(), s.begin());

    if(where.first == v.end())
       std::cout << "Match found." << std::endl;
    else
      std::cout << "The first mismatch ("
                << *where.first << " != "
                << *where.second
                << ") was found at position "
                << (where.first - v.begin())
                << "." << std::endl;
}
