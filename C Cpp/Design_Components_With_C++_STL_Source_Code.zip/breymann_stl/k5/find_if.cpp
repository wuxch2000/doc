// k5/find_if.cpp
// there are two possibilities to find odd numbers
// with find_if, see below (uncomment next line)
//#define SECOND_POSSIBILITY

#include<algorithm>
#include<vector>
#include<iostream>

#ifdef SECOND_POSSIBILITY
#include<functional>  
#else
class odd {
    public:
       // odd argument yields true
       bool operator()(int x) { return x % 2;}
};
#endif

void display(int x) {  std::cout << x << ' ';}

int main() {
    std::vector<int> v(8);

    for(size_t i = 0; i < v.size(); ++i)
        v[i] = 2*i;                     // all even
    v[5] = 99;                          // an odd number

    // display
    std::for_each(v.begin(), v.end(), display);
    std::cout << std::endl;


    // search for odd number
    std::vector<int>::const_iterator iter
#ifdef SECOND_POSSIBILITY
        = std::find_if(v.begin(), v.end(), std::bind2nd(std::modulus<int>(),2));
#else
        = std::find_if(v.begin(), v.end(), odd());
#endif

    if(iter != v.end()) {
        std::cout << "The first odd number ("
             << *iter
             << ") was found at position "
             << (iter - v.begin())
             << "." << std::endl;
    }
    else std::cout << "No odd number found." << std::endl;
}
