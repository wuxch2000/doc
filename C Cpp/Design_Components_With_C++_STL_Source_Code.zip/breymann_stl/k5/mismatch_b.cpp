// k5/mismatch_b.cpp
#include<algorithm>
#include<vector>
#include<iostream>
#include<cctype>
            
class myCharCompare  {// tolerates upper/lower case spelling
    public:
      bool operator()(char x, char y) {
          // convert to lower case if needed
          return tolower(x) == tolower(y);
      }
};
            
int main() {
    char Text1[] = "Algorithms and Data Structures";
    char Text2[] = "Algorithms and data Struktures"; // 2 errors

    // copy texts into vector (-1 because of null byte)
    std::vector<char> v1(Text1, Text1 + sizeof(Text1)-1);
    std::vector<char> v2(Text2, Text2 + sizeof(Text2)-1);

    // compare with iterator pair 'where'
        std::pair<std::vector<char>::iterator, std::vector<char>::iterator>
        where = std::mismatch(v1.begin(), v1.end(), v2.begin());
    
    if(where.first != v1.end()) {
        std::cout << Text1 << std::endl << Text2 << std::endl;
        std::cout.width(1 + where.first - v1.begin());

        std::cout << "^";
        std::cout << "  first mismatch" << std::endl;
    }

    // compare with predicate
    where = std::mismatch(v1.begin(), v1.end(), v2.begin(),
                  myCharCompare());

    if(where.first != v1.end()) {
        std::cout << Text1 << std::endl << Text2 << std::endl;
        std::cout.width(1 + where.first - v1.begin());
        std::cout << "^";  
        std::cout << "  first mismatch at\n"
                "tolerance of upper/lower case spelling"
             << std::endl;
    }
}
