// k5/set_algorithms.cpp
#include<algorithm>
#include<set>
#include<showseq.h>
using namespace std;

int main () {
    int v1[] = {1, 2, 3, 4};
    int v2[] = {0, 1, 2, 3, 4, 5, 7, 99, 13};
    int v3[] = {-2, 5, 12, 7, 33};

    /*  initialize sets with the vector contents
   default comparison object: less<int>()
    (implicit automatic sorting).
       sizeof v/sizeof *v1 = number of elements in v
    */   
    set<int> s1(v1, v1 + sizeof v1/sizeof *v1);
    set<int> s2(v2, v2 + sizeof v2/sizeof *v2);
    set<int> s3(v3, v3 + sizeof v3/sizeof *v3);
    set<int> Result;          // empty set (s1, s2, s3 as above)

    if(includes(s2.begin(), s2.end(), s1.begin(), s1.end())) {
        br_stl::showSequence(s1);              // 1 2 3 4
        cout << " is a subset of ";
        br_stl::showSequence(s2);              // 0 1 2 3 4 5 7 99
    }

    set_union(s1.begin(), s1.end(),
              s3.begin(), s3.end(),
              inserter(Result, Result.begin()));      

    br_stl::showSequence(s1);                  // 1 2 3 4
    cout << " united with ";
    br_stl::showSequence(s3);                  // -2 5 7 12 33
    cout << " yields ";
    br_stl::showSequence(Result);            // -2 1 2 3 4 5 7 12 33

    Result.clear();                  // empty the set
    set_intersection(s2.begin(), s2.end(),
                     s3.begin(), s3.end(),
                     inserter(Result, Result.begin()));

    br_stl::showSequence(s2);                  // 0 1 2 3 4 5 7 99
    cout << " intersected with ";
    br_stl::showSequence(s3);                  // -2 5 7 12 33
    cout << " yields ";
    br_stl::showSequence(Result);            // 5 7

    Result.clear();
    set_difference(s2.begin(), s2.end(),
                   s1.begin(), s1.end(),
                   inserter(Result, Result.begin()));

    br_stl::showSequence(s2);                  // 0 1 2 3 4 5 7 99
    cout << " minus ";
    br_stl::showSequence(s1);                  // 1 2 3 4
    cout << " yields ";
    br_stl::showSequence(Result);              // 0 5 7 99

    Result.clear();
    set_symmetric_difference(s2.begin(), s2.end(),
                             s3.begin(), s3.end(),
                 inserter(Result, Result.begin()));

    br_stl::showSequence(s2);                  // 0 1 2 3 4 5 7 99
    cout << "  exclusive or ";
    br_stl::showSequence(s3);                  // -2 5 7 12 33
    cout << "yields ";
    br_stl::showSequence(Result);              // -2 0 1 2 3 4 12 33 99
}

