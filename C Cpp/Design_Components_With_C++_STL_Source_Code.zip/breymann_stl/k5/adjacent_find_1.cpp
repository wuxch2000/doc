// k5/adjacent_find_1.cpp
#include<algorithm>
#include<vector>
#include<iostream>
#include<showseq.h>

class doubled {
    public:
       bool operator()(int a, int b) { return (b == 2*a);}
};

int main() {
    std::vector<int> v(8);

    for(size_t i = 0; i < v.size(); ++i)
        v[i] = i*i;
    v[6] = 2 * v[5];       // twice as large successor
    br_stl::showSequence(v);

    // search for twice as large successor
    std::vector<int>::const_iterator iter
        = std::adjacent_find(v.begin(), v.end(), doubled());

    if(iter != v.end()) {
        std::cout << "The first number ("
             << *iter
             << ") with a twice as large successor"
                " was found at position "
             << (iter - v.begin())
             << "." << std::endl;
    }
    else std::cout << "No number with twice as large "
                 "successor found." << std::endl;
}
