// k5/find_first_of.cpp
// find an element of subsequence within a sequence

#include<algorithm>
#include<vector>
#include<iostream>

using namespace std;

int main() {
    vector<int> v(8);
    vector<int> subsequence(3);

    /* initialize vector and subsquence */
    for(size_t i = 0; i < v.size(); ++i)
        v[i] = 2*i;                     // all even

    subsequence[0] = 1;
    subsequence[1] = 5;
    subsequence[2] = 7;

    // Two tests:
    for(int testNo =0; testNo<2; ++testNo) {
      if(testNo == 1) {
         subsequence[1] = 6;
         cout << endl << "subsequence modified" << endl;
      }
      cout << "Is one of the elements in the sequence (";
      for(size_t i = 0; i < subsequence.size(); ++i)
         cout << subsequence[i] << " ";
      cout << ") contained in the vector" << endl;

      for(size_t i = 0; i < v.size(); ++i)
         cout << v[i] << " ";
      cout << "?" << endl;

      // search for element, which is also in subsequence 
      vector<int>::const_iterator iter
          = find_first_of(v.begin(), v.end(), subsequence.begin(), subsequence.end());

      if(iter != v.end()) {
          cout << "Yes. Element " << *iter
               << " is present in both ranges. Its first occurrence in the vector is position "
               << (iter - v.begin())
               << "." << endl;
      }
      else cout << "No." << endl;
    } // for testNo
}
