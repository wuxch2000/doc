// k5/sort.cpp
#include<algorithm>
#include<vector>
#include<showseq.h>
#include<rand.h>
using namespace std;

bool integer_less(double x, double y) {   
   return long(x) < long(y);
}

int main() {
    vector<double> v(17);
    br_stl::RAND aChance;

    // initialize vector with random values, with
    // many values having the same integer part:

    for(size_t i = 0; i < v.size(); ++i) {
        v[i] =  aChance(3)
               + double(aChance(100)/1000.0);
    }

    random_shuffle(v.begin(), v.end(), aChance);

    vector<double> unstable = v,       // auxiliary vectors
                     stable = v;

    cout << "Sequence             :\n";
    br_stl::showSequence(v);

    // sorting with < operator:
    stable_sort(stable.begin(), stable.end());
    cout << "\n no difference, because double number "
            "is used as key\n";
    cout << "stable sorting   :\n";
    br_stl::showSequence(stable);

    sort(unstable.begin(), unstable.end());
    cout << "unstable sorting :\n";
    br_stl::showSequence(unstable);

    //  sorting with function instead of < operator:
    unstable = v;
    stable = v;
    cout << "\n differences, because only the int part "
            "is used as key\n";

    stable_sort(stable.begin(), stable.end(),integer_less);
    cout << "stable sorting (integer key)  :\n";
    br_stl::showSequence(stable);

    sort(unstable.begin(), unstable.end(), integer_less);
    cout << "unstable sorting (integer key):\n";
    br_stl::showSequence(unstable);
}
