// k5/merge1.cpp
#include<algorithm>
#include<showseq.h>
#include<vector>

int main() {
    std::vector<int> v(16);                   // even number
    int middle = v.size()/2;
    for(int i = 0; i < middle; ++i) {
        v[i]         = 2*i;              // even
        v[middle + i] = 2*i + 1;         // odd
    }
    br_stl::showSequence(v);
    std::inplace_merge(v.begin(), v.begin() + middle, v.end());
    br_stl::showSequence(v);
}
