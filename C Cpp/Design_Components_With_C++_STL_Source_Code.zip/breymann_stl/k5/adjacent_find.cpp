// k5/adjacent_find.cpp
#include<algorithm>
#include<vector>
#include<iostream>
#include<showseq.h>

int main() {
    std::vector<int> v(8);

    for(size_t i = 0; i < v.size(); ++i)
        v[i] = 2*i;            // even
    v[5] = 99;                 // two identical adjacent elements
    v[6] = 99;
    br_stl::showSequence(v);

    // find identical neighbors
    std::vector<int>::const_iterator iter
        = std::adjacent_find(v.begin(), v.end());

    if(iter != v.end()) {
        std::cout << "The first identical adjacent numbers ("
             << *iter
             << ") were found at position "
             << (iter - v.begin())
             << "." << std::endl;
    }
    else
      std::cout << "No identical adjacent numbers found."
           << std::endl;
}
