// k5/permute.cpp
#include<algorithm>
#include<showseq.h>
#include<vector>
#include<iota.h>
using namespace std;

long factorial(unsigned n) {
    long fac = 1;
    while(n > 1) fac *= n--;
    return fac;
}

int main() {
    vector<int> v(4);
    br_stl::iota(v.begin(), v.end(), 0);     // 0 1 2 3
    long fac = factorial(v.size());

    for(int i = 0; i < fac; ++i) {
        if(!prev_permutation(v.begin(), v.end()))
          cout << "Start of cycle:\n";
        br_stl::showSequence(v);
    }
}
