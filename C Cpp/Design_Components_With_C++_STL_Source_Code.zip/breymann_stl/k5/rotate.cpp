// k5/rotate.cpp
#include<showseq.h>
#include<algorithm>
#include<vector>
#include<iota.h>
using namespace std;

int main() {
    vector<int> v(10);
    br_stl::iota(v.begin(), v.end(), 0);

    for(size_t shift = 1; shift < 3; shift++) {
       cout << "Rotation by " << shift << endl;
       for(size_t i = 0; i < v.size()/shift; ++i) {
          br_stl::showSequence(v);
          rotate(v.begin(), v.begin() + shift, v.end());
       }
    }
}
