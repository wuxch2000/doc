// k5/transform.cpp
#include<algorithm>
#include<showseq.h>
#include<string>
#include<vector>

std::string upper_case(std::string s) {   // unary operation as function
    for(size_t i = 0; i < s.length(); ++i)
        if(s[i] >= 'a' && s[i] <= 'z')
           s[i] -= 'a'-'A';
    return s;
}

class join {              // binary operation as functor
    public:
       std::string operator()(const std::string& a, const std::string& b) {
            return a + " and " + b;
       }
};

int main() {
    std::vector<std::string> Gals(3), Guys(3),
                   Couples(3);   // there must be enough space
    Gals[0] = "Annabella";
    Gals[1] = "Scheherazade";
    Gals[2] = "Xaviera";

    Guys[0]  = "Bogey";
    Guys[1]  = "Amadeus";
    Guys[2]  = "Wladimir";

    std::transform(Guys.begin(), Guys.end(),
              Guys.begin(),   // target == source
              upper_case);

    std::transform(Gals.begin(), Gals.end(),
              Guys.begin(), Couples.begin(),
              join());

    br_stl::showSequence(Couples, "\n");
}
