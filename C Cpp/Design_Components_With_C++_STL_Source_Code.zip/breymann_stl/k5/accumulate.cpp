// k5/accumulate.cpp
#include<iota.h>
#include<vector>
#include<numeric>
#include<iostream>
using namespace std;

int main() {
    vector<int> v(10);
    br_stl::iota(v.begin(), v.end(), 1);

    cout << "Sum = "
         << accumulate(v.begin(), v.end(), 0)    // 55
         << endl;

    cout << "Product = "
         << accumulate(v.begin(), v.end(), 1L,
                       multiplies<long>())            // 3628800
         << endl;
}
