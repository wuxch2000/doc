// reverse_iterator.cpp Reverse-Iterator
#include<iostream>
#include<vector>
#include<showseq.h>

int main() {
  std::vector<int> V(10);
  for(size_t i=0; i< V.size(); ++i)
      V[i]=i;
  br_stl::showSequence(V);
  std::cout << "reverse:" << std::endl;
  std::vector<int>::reverse_iterator RI=V.rbegin();
  while(RI != V.rend())
  {  std::cout << (*RI) << "  ";
     ++RI;
  }
}
