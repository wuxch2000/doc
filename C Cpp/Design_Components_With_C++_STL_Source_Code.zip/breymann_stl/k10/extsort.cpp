// k10/extsort.cpp
// Sorting of a large file
#include<functional>   // greater<>
#include<iostream>

#include"extsort.h"

int main() {
   std::less<long> Comparison;               // descending
   //    std::greater<long> Comparison;             // ascending
    std::istream_iterator<long> suitable_iterator;

    std::cout << externalSorting(
                suitable_iterator,  // type of file
                "random.dat",       // file name
                "\n",               // separator
                Comparison)         // sorting criterion
         << " sorting runs" << std::endl;
}
