// generate file with random numbers
#include<cstdlib>
#include<fstream>
#include<iterator>
#include<iostream>

int main() {
    long howmany;
    std::cout << "howmany numbers shall be generated? ";
    std::cin >> howmany;
    std::ofstream dest("random.dat");
    std::ostream_iterator<long> Output(dest, "\n");
    for(long i = 0; i < howmany; ++i)
          *Output++ = long(rand()) * long(rand());
}

