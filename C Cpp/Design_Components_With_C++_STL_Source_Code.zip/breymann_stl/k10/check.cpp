// check sequence in file random.dat (after sorting)
#include<cstdlib>
#include<fstream>
#include<iterator>
#include<iostream>

int main() {
    std::ifstream Source("random.dat");
    std::istream_iterator<long> numberIterator(Source),
                           theEnd, temp = numberIterator;
    bool ok = true;
    enum {undef, up, down} theSequence = undef;

    while(numberIterator != theEnd)  {
//        std::cout << *numberIterator << ' ' << *temp << std::endl;
        if(   (theSequence == up && *numberIterator < *temp)
           || (theSequence == down  && *temp < *numberIterator)) {
            std::cerr << "Error: " << *numberIterator << std::endl;
            ok = false;
        }
        temp = numberIterator;
        ++numberIterator;
        if(theSequence == undef)
            if(*numberIterator < *temp){
                theSequence = down;
                std::cout << "descending sequence, ";
            }
            else {
                theSequence = up;
                std::cout << "ascending sequence, ";
            }
    }
    if(ok) std::cout << "check ok\n";
    else std::cout << "found error in sequence!\n";
}

