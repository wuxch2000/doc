// k11/toposort/main.cpp
// topological sorting
#include<gr_input.h>
#include<gra_algo.h> // contains toposort()
using namespace std;

int main() {
    br_stl::Graph<string, br_stl::Empty> G(true);             // directed
    br_stl::ReadGraph(G, "topo.dat");

    /* After sorting, the vector Ordering passed as argument contains
       the indices of the graph's vertices.*/
       
    vector<int> Ordering;

    if(br_stl::topoSort(G, Ordering)) {          // sort
       for(size_t i = 0; i < G.size(); ++i)
          cout << G[Ordering[i]].first << ' ';
       cout << endl;
    }
    else cout << "Error (e.g. cycle) in the graph!\n";
}
