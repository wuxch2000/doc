#include<algorithm>
#include<graph.h>
#include<gr_input.h>
#include<iostream>

int main() {
    // no edge weighting, therefore type Empty:
    br_stl::Graph<std::string, br_stl::Empty> V(true);        // directed

    br_stl::ReadGraph(V, "gra1.dat");

    V.check();                // display properties

    // display of vertices with successors
    std::cout << V;

    // next: undirected graph
    br_stl::Graph<std::string, br_stl::Empty> VU(false);    // undirected

    br_stl::ReadGraph(VU, "gra1u.dat");

    VU.check();                // display properties

    // display of vertices with successors
    std::cout << VU;
}
