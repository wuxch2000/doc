#include<algorithm>
#include<graph.h>
#include<gr_input.h>

int main() {
    // integer weights
    br_stl::Graph<std::string, int> V(false);        // undirected

    br_stl::ReadGraph(V, "gra2.dat");

    V.check();                // display properties

    // display of vertices with successors
    std::cout << V;
}
