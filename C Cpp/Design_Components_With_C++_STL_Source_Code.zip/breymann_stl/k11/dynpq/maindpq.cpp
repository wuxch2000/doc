#include<dynpq.h>
#include<showseq.h>

int main() {
    br_stl::checkedVector<double> V(8);
    //... assign values to the elements V[i]}
    for(size_t i = 0; i< V.size(); ++i)
        V[i] = 1.1230 + 0.1*i*(int(i)-4);

    br_stl::showSequence(V);

    br_stl::dynamic_priority_queue<double>    DPQ(V);

    // change value V[3]}; correct insertion
    // into DPQ is carried out automatically
    std::cout <<  "DPQ.changeKeyAt(3, -1.162);" << std::endl;
    DPQ.changeKeyAt(3, -1.162);
    br_stl::showSequence(V);

    std::cout <<  "DPQ.changeKeyAt(7, 61.1611);" << std::endl;
    DPQ.changeKeyAt(7, 61.1611);
    br_stl::showSequence(V);

    std::cout <<  "DPQ.changeKeyAt(0, 661.1615);" << std::endl;
    DPQ.changeKeyAt(0, 661.1615);
    br_stl::showSequence(V);

    // outputting and emptying by order of priority
    while(!DPQ.empty()) {
        std::cout << "index: " << DPQ.topIndex()
                  << " value: " << DPQ.topKey() << std::endl;
        DPQ.pop();
    }
    // provoke error:
//    DPQ.changeKeyAt(0, -0.335);
}
