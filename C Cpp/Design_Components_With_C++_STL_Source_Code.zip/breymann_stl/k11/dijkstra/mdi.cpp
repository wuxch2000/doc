// Dijkstar - Algorithm with graph from file
#include<showseq.h>
#include<checkvec.h>
#include<gra_algo.h>
#include<gr_input.h>

int main() {
   // With edge weights of type int
    br_stl::Graph<std::string,int> G(false);          // undirected
    br_stl::ReadGraph(G, "gra2.dat");  // contains minor errors

    G.check(std::cout); // error check and correction

    br_stl::checkedVector<int> Dist, Predec;

    int start=0;

    br_stl::Dijkstra(G, Dist, Predec, start);

    std::cout << "shortest way to "
         << G[start].first << ":\n";

    std::cout << "predecessor of:     is:  "
            "distance to [indices in ()]:\n";

    for(size_t i = 0; i < Predec.size(); ++i) {
        std::cout <<  "    " << G[i].first
             << '(' << i << ')';
        std::cout << "         ";
        if(Predec[i] < 0)
           std::cout << "-"   //  no predecessor of starting point
                << '(' << Predec[i] << ')';
        else
           std::cout << G[Predec[i]].first
                << '(' << Predec[i] << ')';
        std::cout.width(9);
        std::cout << Dist[i] << std::endl;
    }
}
