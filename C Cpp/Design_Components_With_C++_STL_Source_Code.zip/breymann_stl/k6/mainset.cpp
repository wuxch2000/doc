// {\em k6/mainset.cpp}
// Example for sets with set algorithms
// alternatively for set (STL) or HSet(hash) implementation
#include<showseq.h>
#include<setalgo.h>

// compiler switch (see text)
#define STL_SET

#ifdef STL_SET
#include<set>
char msg[] = "std::set chosen";
#else
#include<hset.h>
#include<hashfun.h>
char msg[] = "br_stl::HSet chosen";
#endif
using namespace std;

int main() {
// type definition according to selected implementation
#ifdef STL_SET
   typedef set<int> SET;  //  default comparison object: less<int>()
#else
   typedef br_stl::HSet<int, br_stl::HashFun<int> > SET;
#endif

   cout << msg << endl;
   SET  Set1, Set2, Result;
   for(int i = 0; i < 10; ++i) Set1.insert(i);
   for(int i = 7; i < 16; ++i) Set2.insert(i);

   // display
   br_stl::showSequence(Set1);
   br_stl::showSequence(Set2);
   cout << "Subset:\n";
   cout << "Includes(Set1, Set2) = "
         << br_stl::Includes(Set1, Set2) << endl;

   cout << "Includes(Set1, Set1) = "
         << br_stl::Includes(Set1, Set1) << endl;

   cout << "Union:\n";
   br_stl::Union(Set1, Set2, Result);
   br_stl::showSequence(Result);

   cout << "Intersection:\n";
   br_stl::Intersection(Set1, Set2, Result);
   br_stl::showSequence(Result);

   cout << "Difference:\n";
   br_stl::Difference(Set1, Set2, Result);
   br_stl::showSequence(Result);

   cout << "Symmetric difference:\n";
   br_stl::Symmetric_Difference(Set1, Set2, Result);
   br_stl::showSequence(Result);

   cout << "Copy constructor:\n";
   SET newSet(Result);
   br_stl::showSequence(newSet);

   cout << "Assignment:\n";
   Result = Set1;
   br_stl::showSequence(Set1);
   br_stl::showSequence(Result);
}

