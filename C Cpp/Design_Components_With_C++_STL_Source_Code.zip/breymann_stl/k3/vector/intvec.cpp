//  k3/vector/intvec.cpp
// example for int-vector container
#include<vector>
#include<iostream>
using namespace std;

int main() {
    // an int vector of 10 elements
    vector<int> intV(10);

    for(size_t i = 0; i < intV.size(); ++i)
       intV[i] = i;                 // fill vector, random access

    // vector increases on demand
    intV.insert(intV.end(), 100);   // append the number 100

    // use as array
    for(size_t i = 0; i < intV.size(); ++i)
       cout << intV[i] << endl;

    // use with an iterator
    for(vector<int>::const_iterator I = intV.begin(); 
                                     I != intV.end(); ++I)
       cout << *I << endl;
    
    vector<int> newV(20, 0); // all elements are 0
    
    cout << " newV = ";

    for(size_t i = 0; i < newV.size(); ++i)
       cout << newV[i] << ' ';

    // swap() is a very fast method for
    // swapping two vectors
    newV.swap(intV);

    cout << "\n newV after swapping = ";
    for(size_t i = 0; i < newV.size(); ++i)
       cout << newV[i] << ' ';     // old contents of intV

    cout << "\n\n intV        = ";
    for(size_t i = 0; i < intV.size(); ++i)
       cout << intV[i] << ' ';     // old contents of newV
    cout << endl;
}
