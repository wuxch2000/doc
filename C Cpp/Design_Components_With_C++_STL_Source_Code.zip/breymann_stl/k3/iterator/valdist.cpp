// k3/iterator/valdist.cpp
// Determination of value and distance types
#include<showseq.h>
#include<list>
#include<vector>
#include<iterator>

template<class BidirectionalIterator>
void reverseIt(BidirectionalIterator first,
            BidirectionalIterator last) {
    reverseIt(first, last, std::iterator_traits<BidirectionalIterator>
                                  ::iterator_category());

}

/* Reversing the order means that one element must be intermediately
   stored. For this, its type must be known. Following the well-proven
   scheme, the function calls the suitable implementation for the
   iterator type:
*/

template<class BidirectionalIterator>
void reverseIt(BidirectionalIterator first,
            BidirectionalIterator last,
            std::bidirectional_iterator_tag) {
    // Use of the difference type to calculate
    // the number of exchanges. The difference type
    // is derived from the iterator type:
    typename std::iterator_traits<BidirectionalIterator>::difference_type
         n = std::distance(first, last) -1; 

    while(n > 0) {
        // The value type is also derived from the iterator type:
        typename std::iterator_traits<BidirectionalIterator>::value_type
            temp = *first;      
        *first++ = *--last;
        *last = temp;
        n -= 2;
    }
}

// The second implementation uses arithmetic to compute
// the distance, which is possible only with
// random access iterators:

template<class RandomAccessIterator>
void reverseIt(RandomAccessIterator first,
            RandomAccessIterator last,
            std::random_access_iterator_tag) {
    // Use of the difference type to calculate
    // the number of exchanges. The difference type
    // is derived from the iterator type:
    typename std::iterator_traits<RandomAccessIterator>::difference_type
      n = last -first -1; // arithmetic! 

    while(n > 0) {
        // The value type is also derived from the iterator type:
        typename std::iterator_traits<RandomAccessIterator>::value_type
            temp = *first;      
        *first++ = *--last;
        *last = temp;
        n -= 2;
    }
}


/* At first sight, one could think that the algorithm could do without
   the distance type when comparing iterators and stop when first
   becomes >=  last. However, this assumption only holds when a >
   relation is defined for the iterator type at all. For a vector,
   where two pointers point to a continuous memory area, this is no
   problem. It is, however, impossible for containers of a different
   kind, such as lists or binary trees. */

int main() {
    std::list<int> L;
    for(int i=0; i < 10; ++i) L.push_back(i);
    reverseIt(L.begin(), L.end());
    br_stl::showSequence(L);

    std::vector<double> V(10);
    for(int i = 0; i < 10; ++i) V[i] = i/10.;
    reverseIt(V.begin(), V.end());
    br_stl::showSequence(V);
}
