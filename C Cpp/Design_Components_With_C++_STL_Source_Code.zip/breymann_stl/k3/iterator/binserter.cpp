// k3/iterator/binserter.cpp uses  back_inserter()
// Insert iterators : back insert
#include<showseq.h>
#include<vector>
#include<iterator>

template <class InputIterator, class OutputIterator>
OutputIterator copyadd(InputIterator first,
                       InputIterator last,
                       OutputIterator result) {
    while (first != last) 
        *result++ = *first++;
    return result;
}

int main() {
    std::vector<int> aVector(5, 0);      // 5 zeros
    std::cout << "aVector.size() = "
         << aVector.size() << std::endl; // 5
    br_stl::showSequence(aVector);          // 0 0 0 0 0

   // copying with function {\tt back\_inserter()}
    std::vector<int> aVector2;            // size is 0
    copyadd(aVector.begin(), aVector.end(),
                             std::back_inserter(aVector2));
    std::cout << "aVector2.size() = "
              << aVector2.size() << std::endl; // {\sl 7}
    br_stl::showSequence(aVector2);          
}

