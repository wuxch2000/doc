// k3/iterator/finsert.cppc
// Insert iterators: front inserter
#include<showseq.h>
#include<list>
#include<iterator>

int main() {
    std::list<int> aList(5, 0);     // 5 zeros

    std::cout << "aList.size() = "
              << aList.size() << std::endl;

    br_stl::showSequence(aList);

    std::front_insert_iterator<std::list<int> >
                              aFrontInserter(aList);

    // insertion by means of the operations *, ++, =
    int i = 1;
    while(i < 3)
          *aFrontInserter++ = i++;

    std::cout << "aList.size() = "
              << aList.size() << std::endl;

    br_stl::showSequence(aList);
}
