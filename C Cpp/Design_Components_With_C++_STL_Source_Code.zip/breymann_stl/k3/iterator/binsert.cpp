// k3/iterator/binsert.cpp
// Insert iterators : back insert
#include<showseq.h>
#include<vector>
#include<iterator>

int main() {
    std::vector<int> aVector(5, 0);      // 5 zeros
    std::cout << "aVector.size() = "
         << aVector.size() << std::endl; // 5
    br_stl::showSequence(aVector);          // 0 0 0 0 0

    std::back_insert_iterator<std::vector<int> >
                      aBackInserter(aVector);   

    // insertion by means of the operations *, ++, =
    int i = 1;
    while(i < 3)
          *aBackInserter++ = i++;

    std::cout << "aVector.size() = "
         << aVector.size() << std::endl;  // 7

    br_stl::showSequence(aVector);           // 0 0 0 0 0 1 2
}

