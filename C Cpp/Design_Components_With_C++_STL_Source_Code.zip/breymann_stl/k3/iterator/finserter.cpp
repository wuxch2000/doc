// k3/iterator/finserter.cpp uses  std::front_inserter()
// Insert iterators: front inserter
#include<showseq.h>
#include<list>
#include<iterator>

template <class InputIterator, class OutputIterator>
OutputIterator copyadd(InputIterator first,
                       InputIterator last,
                       OutputIterator result) {
    while (first != last) 
        *result++ = *first++;
    return result;
}

int main() {
    std::list<int> aList(5, 0);     // 5 zeros

    std::cout << "aList.size() = "
              << aList.size() << std::endl;

    br_stl::showSequence(aList);
    std::list<int> aList2;         // empty

    copyadd(aList.begin(), aList.end(), 
            std::front_inserter(aList2));


    std::cout << "aList2.size() = "
              << aList2.size() << std::endl;

    br_stl::showSequence(aList2);
}
