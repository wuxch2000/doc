// k3/iterator/insert.cpp
// Insert iterator
#include<showseq.h>
#include<vector>
#include<iterator>

int main() {
    std::vector<int> aVector(5, 0);      // 5 zeros

    std::cout << "aVector.size() = "
         << aVector.size() << std::endl;  //  5
    br_stl::showSequence(aVector);   //  0 0 0 0 0

    // insertion by means of the operations *, ++, =
    std::insert_iterator<std::vector<int> >
        aBeginInserter(aVector, aVector.begin());

    int i = 1;
    while(i < 3) 
         *aBeginInserter++ = i++;
    // vector:  1 2 0 0 0 0 0
    // size() is now 7

    std::insert_iterator<std::vector<int> >
        aMiddleInserter(aVector, aVector.begin() +
                         aVector.size()/2);

    while(i < 6)
       *aMiddleInserter++   = i++;
    // vector:  1 2 0 3 4 5 0 0 0 0
    // size() is now 10

    std::insert_iterator<std::vector<int> >
        anEndInserter(aVector, aVector.end());
    while(i < 9) 
         *anEndInserter++    = i++;

    std::cout << "aVector.size() = "
         << aVector.size() << std::endl;  //  13
    br_stl::showSequence(aVector);   //  1 2 0 3 4 5 0 0 0 0 6 7 8
}
