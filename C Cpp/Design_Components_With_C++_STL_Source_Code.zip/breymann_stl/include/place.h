// include/place.h
#ifndef PLACE_H
#define PLACE_H
#include<cmath>
#include<string>

namespace br_stl {

class Place {
  public:
    Place() {};

    Place(long int ax, long int ay, const std::string& N = std::string(""))
    : x(ax), y(ay), Name(N) {
    }

    const std::string& readName() const { return Name;}
    unsigned long int X() const { return x;}
    unsigned long int Y() const { return y;}

    bool operator==(const Place& P) const {
        return x == P.x && y == P.y;
    }

    // for alphabetical ordering
    bool operator<(const Place& P) const {
        return Name < P.Name;
    }

  private:
    long int x, y;                    // coordinates
    std::string Name;                      // identifier
};

inline unsigned long int DistSquare(const Place& p, const Place& q) {
   long int dx = p.X()-q.X();
   long int dy = p.Y()-q.Y();
   // (arithmetic overflow with large numbers is not checked)
   return dx*dx + dy*dy;
}

inline double Distance(const Place& p, const Place& q) {
    return std::sqrt(double(DistSquare(p,q)));
}

inline std::ostream& operator<<(std::ostream& os, const Place& S) {
    os << S.readName();
    return os;
}

} // namespace br_stl

#endif

