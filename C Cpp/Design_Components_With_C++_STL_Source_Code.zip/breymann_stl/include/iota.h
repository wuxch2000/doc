#ifndef IOTA_H
#define IOTA_H

namespace br_stl {

template <class ForwardIterator, class T>
void iota(ForwardIterator first, ForwardIterator last, T value) {
  while (first != last) *first++ = value++;
}


}   // namespace br_stl


#endif
