// k1/a4/mainstl2.cpp
#include<algorithm>    // contains  find()
#include<iostream>
#include"slist.h"        // user-defined list class 
using namespace std;

int main() {
    const int count = 100;
    br_stl::slist<int> aContainer;          // define the container

    /* Change of order because the container is filled from the front!
       This example differs from those in 1.3.4, because elements are
       inserted, i.e., the container is expanded as needed. */

    for(int i = count; i >= 0; --i)  // fill the container with
       aContainer.push_front(2*i);   // even numbers

    int Number = 0;
    while(Number != -1) {
       cout << " enter required number (-1 = end):";
       cin >> Number;
       if(Number != -1) {
          // use of container methods:
         br_stl::slist<int>::iterator Position =
             find(aContainer.begin(),
                aContainer.end(), Number);

         if(Position != aContainer.end()) 
            cout << "found at position "
                       << (Position - aContainer.begin()) << endl;
         else cout << "not found\n";
       }
    }
    cout << "test of assignment:\n";
    cout << "aContainer.size =" << aContainer.size() << endl;
    br_stl::slist<int> aSlist;
    aSlist = aContainer;
    cout << "aSlist.size =" << aSlist.size() << endl;
    br_stl::slist<int>::iterator I = aSlist.begin();
    while(I != aSlist.end()) 
      cout << *I++ << " ";
    cout << endl;



}
