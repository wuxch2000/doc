// k1/a4/slist : list template for singly-linked lists
//  T is a placeholder for the data type of a list element.
#ifndef SIMPLELIST_H
#define SIMPLELIST_H SIMPLELIST_H

#include<cassert>
#include<iterator>
namespace br_stl {

template<class T>
class slist {
  public:

    /* Some types of the class get public names. Then it is
       possible to use them outside the class without knowing the
       implementation. */

    typedef T value_type;
    typedef ptrdiff_t difference_type;
    typedef T* pointer;
    typedef T& reference;
    // etc. see text

    slist() : firstElement(0), Count(0) {}
    ~slist() { clear();}

    slist(const slist& sl) 
    : firstElement(0), Count(0){
      if(!sl.empty()) {
        iterator I = sl.begin();
        push_front(*I++);
        ListElement *last = firstElement;
        while(I != sl.end()) {
          // insert elements at the end to preserve the ordering
          last->Next = new ListElement(*I++, 0);
          last = last->Next;
          ++Count;
        }
      }
    }

    slist& operator=(const slist& sl) {
      slist temp(sl);
      // swap mgmt.info. swap() see chapter 5
      std::swap(temp.firstElement, firstElement);
      std::swap(temp.Count, Count);
     return *this;
    }

    bool empty() const { return Count == 0;}
    size_t size() const { return Count;}

    /* The implementation of push_front() creates a new list
       element and inserts it at the beginning of the list: */

    void push_front(const T& Datum) { // insert at beginning
      firstElement =  new ListElement(Datum, firstElement);
      ++Count;
    }

  private:
    struct ListElement {
        T Data;
        ListElement *Next;
        ListElement(const T& Datum, ListElement* p)
        : Data(Datum), Next(p) {}
    };

    ListElement *firstElement;
    size_t Count;

    /* The list consists of list elements whose type is defined inside
       the list class as a nested public class (struct). In a
       structure, direct access to internal data is possible, but this
       is no problem here because the data is located in the private
       section of the slist class. Each list element carries the
       pertinent data, for example a number, together with a pointer
       to the next list element. firstElement is the pointer to the
       first list element. The class slist provides an iterator type
       iterator which is located in the public section since it is to
       be publicly accessible. It is also used in the following main()
       program. An iterator object stores the current container
       position in the current attribute. The methods satisfy the
       requirements formulated for iterators. */

  public:
    class iterator {
       friend class slist;
       public:
        typedef std::forward_iterator_tag iterator_category;
        typedef T value_type;
        typedef T* pointer;
        typedef T& reference;
        typedef size_t size_type;
        typedef ptrdiff_t difference_type;

         iterator(ListElement* Init = 0)
         : current(Init){}

         T& operator*() {             // dereferencing
             return current->Data;
         }

         const T& operator*() const { // dereferencing
             return current->Data;
         }

         iterator& operator++() {     // prefix
            if(current) // not yet arrived at the end?
               current = current->Next;
            return *this;
         }

         iterator operator++(int) {   // postfix
            iterator temp = *this;
            ++*this;
            return temp;
         }

         bool operator==(const iterator& x) const {
            return current == x.current;
         }

         bool operator!=(const iterator& x) const {
            return current != x.current;
         }

       private:        
         ListElement* current; // pointer to current element 
    }; // iterator

 /* Some methods of the 
{\tt slist} class use the {\tt iterator} class:*/

    iterator begin() const { return iterator(firstElement);}
    iterator end()   const { return iterator();}

    iterator erase(iterator position) {
       if(!firstElement) return end(); // empty list
       iterator Successor = position;
       ++Successor;

       // look for predecessor
       ListElement *toBeDeleted = position.current,
                     *Predecessor = firstElement;

       if(toBeDeleted != firstElement) {
          while(Predecessor->Next != toBeDeleted)
                Predecessor = Predecessor->Next;
          Predecessor->Next = toBeDeleted->Next;
       }
       else // delete at firstElement
            firstElement = toBeDeleted->Next;
       delete toBeDeleted;
       --Count;
       return Successor;
    }

     void clear() {
         while(begin() != end())
             erase(begin());
     }
};

template<class Iterator>
int operator-(Iterator second, Iterator first) {
  //  similar to std::distance(first, second);
  int count = 0;
   /* The difference between the iterators
is determined by incrementing {\tt first} until the second
iterator is reached. Thus, the condition is that {\tt first} lies 
{\em not after} the second iterator. In other words: {\tt second} must be 
reachable by first by means of the {\tt ++} operator.*/
  while(first != second 
        && first != Iterator()) {
    ++first;
    ++count;
  }
   // In case of inequality, second is not reachable by first
  assert(first == second);
  return count;
}

} // namespace br_stl
#endif //  SIMPLELIST_H

