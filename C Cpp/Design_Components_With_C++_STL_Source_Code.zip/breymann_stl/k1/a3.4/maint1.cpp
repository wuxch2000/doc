// k1/a3.4/maint1.cpp
// variation 2: algorithm as template
template<class Iteratortype, class T>
Iteratortype find(Iteratortype begin, Iteratortype end,
                  const T& Value) {
    while(begin != end        // iterator comparison
          && *begin != Value) // dereferencing and object comparison
         ++begin;             // next position
    return begin;
}

// rest as before:
#include<iostream>

// new type name Iterator for `pointer to const int'
typedef const int* Iterator;

int main() {
    const int Count = 100;
    int aContainer[Count];          // define container

    Iterator begin = aContainer;    // pointer to the beginning

    //  position after the last element
    Iterator end = aContainer + Count;

    // fill container with even numbers
    for(int i = 0; i < Count; ++i)
       aContainer[i] = 2*i;

    int Number = 0;
    while(Number != -1) {
       std::cout << " enter required number (-1 = end):";
       std::cin >> Number;
       if(Number != -1) {
          Iterator position = find(begin, end, Number);

          if (position != end)
            std::cout << "found at position "
                      << (position - begin) << std::endl;
          else std::cout << Number << " not found!" << std::endl;
       }
    }
}

