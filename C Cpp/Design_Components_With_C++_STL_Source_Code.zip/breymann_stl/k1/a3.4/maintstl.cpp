// k1/a3.4/maintstl.cpp
// variation 4: STL algorithm 
#include<algorithm>
// ... rest as variation 3, but without find() template
#include<iostream>
#include<vector>  // STL

// new type name 'IteratorType'
typedef std::vector<int>::const_iterator IteratorType;

int main() {
    const int Count = 100;
    std::vector<int> aContainer(Count);   // define container
    for(int i = 0; i < Count; ++i)   // fill container with
        aContainer[i] = 2*i;         // even numbers

    int Number = 0;
    while(Number != -1) {
       std::cout << " enter required number (-1 = end):";
       std::cin >> Number;
       if(Number != -1) {
         // use of container methods:
         IteratorType position =
             find(aContainer.begin(),
               aContainer.end(), Number);

         if (position != aContainer.end())
            std::cout << "found at position "
                      << (position - aContainer.begin()) << std::endl;
         else std::cout << Number << " not found!" << std::endl;
       }
    }
}
