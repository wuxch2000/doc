// k1/a3.4/main.cpp
// (File names refer to the examples which are available via FTP.)
// variation 1, without using the STL
#include<iostream>
using namespace std;

// new type name IteratorType for `pointer to const int'
// (we don't want to modify the values here)
typedef const int* IteratorType;

// prototype of the algorithm
IteratorType find(IteratorType begin, IteratorType end, const int& Value);

int main() {
    const int Count = 100;
    int aContainer[Count];          // define container

    IteratorType begin = aContainer;    // pointer to the beginning

    //  position after the last element
    IteratorType end = aContainer + Count;

    // fill container with even numbers
    for(int i = 0; i < Count; ++i)
       aContainer[i] = 2*i;

    int Number = 0;
    while(Number != -1) {
       cout << " enter required number (-1 = end):";
       cin >> Number;
       if(Number != -1) {           // continue?
         IteratorType position = find(begin, end, Number);

         if (position != end)
            cout << "found at position "
                      << (position - begin) << endl;
         else 
            cout << Number << " not found!" << endl;
       }
    }
}

// implementation
IteratorType find(IteratorType begin, IteratorType end,
              const int& Value) {
    while(begin != end        // pointer comparison
          && *begin != Value) // dereferencing and object comparison
         ++begin;             // next position
    return begin;
}
