// k9/a1/strvec.cpp
// std::string vector container with index check
#include<checkvec.h>   // contains checkedVector
#include<iostream>
#include<string> 

int main() {
    // a string vector of 4 elements
    br_stl::checkedVector<std::string> stringVec(4);
    stringVec[0] = "first";
    stringVec[1] = "second";
    stringVec[2] = "third";
    stringVec[3] = "fourth";
    std::cout << "!! provoked program abort:" << std::endl;
    stringVec[4] = "index error";  
}
