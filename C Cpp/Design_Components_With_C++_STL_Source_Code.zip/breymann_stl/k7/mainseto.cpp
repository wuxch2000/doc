// k7/mainseto.cpp
#include<showseq.h>
#include<hset.h>
#include<hashfun.h>
using namespace std;
using namespace br_stl;


int main() {
    typedef HSet<int, HashFun<int> > SET;
    SET  Set1, Set2, Result;
    for(int i = 0; i < 10; ++i) Set1.insert(i);
    for(int i = 7; i < 16; ++i) Set2.insert(i);

    showSequence(Set1);    // 0 1 2 3 4 5 6 7 8 9
    showSequence(Set2);    // 7 8 9 10 11 12 13 14 15

    cout << "Union: set += set\n";
    Result = Set1;
    Result += Set2;

    showSequence(Result);  // 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15

    cout << "Intersection: set *= set\n";
    Result = Set1;
    Result *= Set2;

    showSequence(Result);  // 7 8 9

    cout << "Union: result = set + set\n";
    Result = Set1 + Set2;

    showSequence(Result);  // 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15

    cout << "Intersection: result = set * set\n";
    Result = Set1 * Set2;
    showSequence(Result);  // 7 8 9

    cout << "Difference:  result = set - set\n";
    Result = Set1 - Set2;

    showSequence(Result);  // 0 1 2 3 4 5 6

    cout << "Symmetric difference: result = set ^ set\n";
    Result = Set1 ^ Set2;

    showSequence(Result);  // 0 1 2 3 4 5 6 10 11 12 13 14 15
}
